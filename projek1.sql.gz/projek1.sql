-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 18, 2014 at 12:23 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `projek1`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE IF NOT EXISTS `artikel` (
  `id_artikel` int(100) NOT NULL AUTO_INCREMENT,
  `isi_artikel` text NOT NULL,
  PRIMARY KEY (`id_artikel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `artikel`
--


-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `chtime` datetime NOT NULL,
  `nick` varchar(20) NOT NULL,
  `word` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--


-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `id_gallery` int(100) NOT NULL AUTO_INCREMENT,
  `nama_gambar` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` time NOT NULL,
  PRIMARY KEY (`id_gallery`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `gallery`
--


-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
  `id_komentar` int(100) NOT NULL AUTO_INCREMENT,
  `isi_komentar` text NOT NULL,
  `nama_gambar` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` time NOT NULL,
  PRIMARY KEY (`id_komentar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `komentar`
--


-- --------------------------------------------------------

--
-- Table structure for table `personal`
--

CREATE TABLE IF NOT EXISTS `personal` (
  `id_chating_personal` int(4) NOT NULL AUTO_INCREMENT,
  `pengirim` varchar(20) DEFAULT NULL,
  `penerima` varchar(50) DEFAULT NULL,
  `waktu_kirim` time DEFAULT NULL,
  `pesan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_chating_personal`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `personal`
--

INSERT INTO `personal` (`id_chating_personal`, `pengirim`, `penerima`, `waktu_kirim`, `pesan`) VALUES
(5, 'neng@yahoo.com', 'neng@yahoo.com', '03:53:02', 'pagi'),
(6, 'koswar@gmail.com', 'koswar@gmail.com', '03:53:13', 'juga'),
(7, 'neng@yahoo.com', 'neng@yahoo.com', '03:54:52', 'lagi apa /'),
(8, 'koswar@gmail.com', 'koswar@gmail.com', '03:55:08', 'diem aja, kamu ?');

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE IF NOT EXISTS `pesan` (
  `id_pesan` int(4) NOT NULL AUTO_INCREMENT,
  `pesan` varchar(250) DEFAULT NULL,
  `tanggal` date NOT NULL,
  `waktu` time NOT NULL,
  PRIMARY KEY (`id_pesan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pesan`
--


-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `id_status` int(100) NOT NULL AUTO_INCREMENT,
  `isi_status` text NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` time NOT NULL,
  PRIMARY KEY (`id_status`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `status`
--


-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(100) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `verif_password` varchar(100) DEFAULT NULL,
  `nama_pengguna` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `alamat` text NOT NULL,
  `sekolah` text NOT NULL,
  `pekerjaan` text NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `email`, `password`, `verif_password`, `nama_pengguna`, `tanggal_lahir`, `gender`, `alamat`, `sekolah`, `pekerjaan`) VALUES
(1, 'ara@ymail.com', 'koswara', 'koswara', 'ara', '1993-05-12', 'laki-laki', '', '', ''),
(2, 'neng@yahoo.com', 'nurinten', 'nurinten', 'inten', '1994-09-02', 'perempuan', '', '', ''),
(3, 'koswar@gmail.com', 'koswara', 'koswara', 'koswara', '1993-12-05', 'Laki-laki', 'sukabumi', 'smk n 1 panji', 'mahasiswa');
